import { productPageFactory } from "@/features/product/productPageFactory";
export const { Page, generateMetadata } = productPageFactory("anime");
export default Page;
