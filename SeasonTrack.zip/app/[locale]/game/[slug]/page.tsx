import { productPageFactory } from "@/features/product/productPageFactory";
export const { Page, generateMetadata } = productPageFactory("game");
export default Page;
