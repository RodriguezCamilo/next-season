import { productPageFactory } from "@/features/product/productPageFactory";
export const { Page, generateMetadata } = productPageFactory("esport");
export default Page;
