import { productPageFactory } from "@/features/product/productPageFactory";
export const { Page, generateMetadata } = productPageFactory("show");
export default Page;
