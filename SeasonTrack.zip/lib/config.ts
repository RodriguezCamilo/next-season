export const SITE_NAME = "SeasonTrack";

export const TAGLINE_ES =
  "Sigue las próximas temporadas de tus series, animes y juegos.";
export const TAGLINE_EN =
  "Track upcoming seasons for your favorite shows, anime and games.";
